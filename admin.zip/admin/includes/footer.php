<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2018 ToNiagara. All Rights Reserved | Design by  <a href="http://toniagara.com/" target="_blank">ToNiagara</a></p>
</div>	
<!--copy rights end here-->
<!-- js -->
<script src="js/modernizr.custom.js"></script>
<script src="js/classie.js"></script>
<script src="js/gnmenu.js"></script>
<script>
new gnMenu( document.getElementById( 'gn-menu' ) );
</script>
<!-- //js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<?php
$conn->close();
?>